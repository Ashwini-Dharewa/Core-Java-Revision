package com.capgemini.bank;

public class CurrentAccount2 extends CurrentAccount implements Insurance{
	public String getPolicyNumber() {
		// TODO Auto-generated method stub
		return policyNumber;
	}

	
	public double getmonthlyPrem() {
		// TODO Auto-generated method stub
		return monthlyPrem;
	}

}
