package com.capgemini.bank;

//import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.TreeSet;
//import java.util.List;

public class BankAccountCollections {
	//LinkedList<BankAccount> ob=new LinkedList<BankAccount>();
	//List<BankAccount> ob=new ArrayList<BankAccount>();
	//HashSet<BankAccount> ob=new HashSet<BankAccount>();
	//For TreeSet,implement Comparable in Bank Account and override compareTo()
	TreeSet<BankAccount> ob=new TreeSet<BankAccount>();
	static int i=0;
	
	public void createAccount(BankAccount acc)
	{
			ob.add(acc);
	}
	
	
	public TreeSet<BankAccount> deleteAccount(int accountNum)
	{
		for(BankAccount account:ob)
		{
			if(account.getAccountNo()==accountNum)
			{
				ob.remove(account);
				return ob;
			}
		}
		throw new RuntimeException("Account does not exist!");
		/*
		 * ob.remove(accountNum); //remove by index
		 * return ob;
		 */		
	}
	
	//HashSet does not support sort()
	
	
	/*public HashSet<BankAccount> sortByName()
	{
		 ob.sort((BankAccount acc1,BankAccount acc2)->acc1.getAccountHolderName().compareTo(acc2.getAccountHolderName()));
		 return ob;
	}
	
	public HashSet<BankAccount> sortByNameV2()
	{
		 Collections.sort(ob,new Comparator<BankAccount>(){
			 @Override
			 public int compare(BankAccount acc1,BankAccount acc2)
			 {
				 return acc1.getAccountHolderName().compareTo(acc2.accountHolderName);
			 }
		 });
		 return ob;
	}*/
	
	
	public TreeSet<BankAccount> getAllAccount()
	{
		return ob;
	}
	public TreeSet<BankAccount> updateAccount(int accountNum,String name)
	{
		for(BankAccount account:ob)
		{
			if(account.getAccountNo()==accountNum)
			{
				account.setAccountHolderName(name);
				return ob;
			}
		}
		throw new RuntimeException("Account does not exist!");
		
	}
	
	public BankAccount getAccountInfoById(int accountNum)
	{
		for(BankAccount account:ob)
		{
			if(account.getAccountNo()==accountNum)
			{
				return account;
			}
		}
		throw new RuntimeException("Account does not exist!");
		//return ob.get(accountNum)
	}
	
	public static void main(String[] args) {
		BankAccountCollections list=new BankAccountCollections();
		System.out.println("After creation:");
		list.createAccount(new SavingAccount("Ashwini", 4578));
		list.createAccount(new SavingAccount("Swagata", 89578));
		list.createAccount(new SavingAccount("Tanusree", 9578));
		for(BankAccount listing:list.getAllAccount())
			System.out.println(listing);
		System.out.println("After deleting:");
		
		for(BankAccount listing:list.deleteAccount(2))
			System.out.println(listing);
		
		System.out.println("Get info for Id=1:");
		System.out.println(list.getAccountInfoById(1));
		
		System.out.println("After updating name:");
		for(BankAccount listing:list.updateAccount(3,"Abhrak"))
			System.out.println(listing);
		
		
		/*System.out.println("After sorting by name:");
		for(BankAccount listing:list.sortByName())
			System.out.println(listing);
		System.out.println("After sorting by name version 2:");
		for(BankAccount listing:list.sortByNameV2())
			System.out.println(listing);*/
		

	}

}

