package com.capgemini.bank;

public interface Insurance {
	
	String policyNumber="Ashwini123";
	double monthlyPrem=23456;
	public String getPolicyNumber();
	public double getmonthlyPrem();
	public String toString();

}
