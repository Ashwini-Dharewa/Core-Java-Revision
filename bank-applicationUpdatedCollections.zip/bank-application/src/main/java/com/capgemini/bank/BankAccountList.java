package com.capgemini.bank;

public class BankAccountList {
	BankAccount ob[]=new BankAccount[4];
	static int i=0;
	
	public void createAccount(BankAccount acc)
	{
			ob[i++]=acc;
	}
	
	
	public BankAccount[] deleteAccount(int accountNum)
	{
		for(int j=0;j<i;j++)
		{
			if(ob[j].accountNo==accountNum)
			{
				for(int k=j;k<i;k++)
				{
					ob[k]=ob[k+1];
					
				}
				//i--;
				return ob;
				
			}
		}
		throw new RuntimeException("Account does not exist!");
		
	}
	
	public BankAccount[] getAllAccount()
	{
		return ob;
	}
	
	
	public BankAccount[] updateAccount(int accountNum,String name)
	{
		for(int j=0;j<i;j++)
		{
			if(ob[j].getAccountNo()==accountNum)
			{
				ob[j].setAccountHolderName(name);
				return ob;
			}
		}
		throw new RuntimeException("Account does not exist!");
		
	}
	
	public BankAccount getAccountInfoById(int accountNum)
	{
		for(int j=0;j<i;j++)
		{
			if(ob[j].getAccountNo()==accountNum)
			{
				return ob[j];
			}
		}
		throw new RuntimeException("Account does not exist!");
	}
	
	
	
	
	public static void main(String[] args) {
		
		
		
		BankAccountList list=new BankAccountList();
		System.out.println("After creation:");
		list.createAccount(new SavingAccount("Ashwini", 4578));
		list.createAccount(new SavingAccount("Swagata", 89578));
		list.createAccount(new SavingAccount("Tanusree", 9578));
		for(BankAccount listing:list.getAllAccount())
			System.out.println(listing);
		
		
				
		System.out.println("After deleting:");
		
		for(BankAccount listing:list.deleteAccount(2))
			System.out.println(listing);
		
		System.out.println("Get info for Id=1:");
		System.out.println(list.getAccountInfoById(1));
		
		System.out.println("After updating name:");
		for(BankAccount listing:list.updateAccount(1, "AshwiniDharewa"))
			System.out.println(listing);
		

	}

}
