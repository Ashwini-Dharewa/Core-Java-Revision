package com.capgemini.bank;

public class SavingAccount2 extends SavingAccount implements Insurance{
	public String getPolicyNumber() {
		// TODO Auto-generated method stub
		return policyNumber;
	}

	
	public double getmonthlyPrem() {
		// TODO Auto-generated method stub
		return monthlyPrem;
	}
	

}
